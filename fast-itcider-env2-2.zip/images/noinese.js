/*
skin name : fast itcider (en version)
version : v2.2
author : itcider.com
website : itcider.com
license : itcider license
warning :
Comments and code modifications are absolutely not allowed
An unlimited number of skins can be applied to the site
Redistribution or unauthorized use of code is strictly prohibited
Copyright notice at the bottom can be removed
Distributable only on itcider official website
If you do not follow the above precautions, you will not be able to use it.
*/
if(/MSIE \d|Trident.*rv:/.test(navigator.userAgent)) {

  window.location = 'microsoft-edge:' + window.location;

  setTimeout(function() {

    window.location = 'https://go.microsoft.com/fwlink/?linkid=2135547';

  }, 1);

}
