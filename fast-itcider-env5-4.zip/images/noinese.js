/*
skin name : fast itcider (en version)
version : V5.4
author : itcider.com
website : itcider.com
license : itcider license
warning :
Comments cannot be edited or deleted
fi skin phrase cannot be deleted
An unlimited number of skins can be applied to the site
Redistribution or unauthorized use of code is strictly prohibited
Distributable only on the itcider official website
If you do not follow the above precautions, you will not be able to use it.
*/
if(/MSIE \d|Trident.*rv:/.test(navigator.userAgent)) {

  window.location = 'microsoft-edge:' + window.location;

  setTimeout(function() {

    window.location = 'https://go.microsoft.com/fwlink/?linkid=2135547';

  }, 1);

}
